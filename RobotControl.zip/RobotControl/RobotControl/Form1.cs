﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Phidgets; //Needed for the MotorControl class, Phidget base classes, and the PhidgetException class
using Phidgets.Events; //Needed for the Phidget event handling classes

namespace RobotControl
{

    public partial class Form1 : Form
    {

        #region Declorations
        private MotorControl motoControl; //Declare a MotorControl object
        bool moto = false;
        bool joyfound = false;
        int RightFront; //Right Front Wheel             
        int RightBack; // Right Back Wheel
        int LeftFront; // Left Front Wheel
        int LeftBack; //Left Back Wheel
        int[] servo = new int[2]; // Servos
        int Phidget_Max = 231; //Max Speed
        int Phidget_Min = -23; //Min Speed
        #endregion

        #region Functions
        private void motoControl_Attach(object sender, AttachEventArgs e)
        {
            moto = true;
        }
        private void motoControl_Detach(object sender, DetachEventArgs e)
        {
            moto = false;
        }

        int Limit_Device(int variable, int max, int min)
        {
            if (variable > max) { variable = max; }
            if (variable < min) { variable = min; }
            return variable;
        }
        #endregion

        #region Joystick

        #endregion

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            motoControl = new MotorControl(); // Initializes MotorControl
            motoControl.Attach += new AttachEventHandler(motoControl_Attach); //Attached Event
            motoControl.Detach += new DetachEventHandler(motoControl_Detach); //Detached Event
            timer1.Enabled = true;
            ErrorCheck.Enabled = true; 
            try
            {
                motoControl.open(); 
            }
            catch (PhidgetException pe)
            {
                MessageBox.Show(pe.ToString());
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (moto)
            {
                motorController.Text = "Connected";
            }
            else {
                motorController.Text = "Not Connected";
            }
            if (joyfound)
            {
                joystick.Text = "Connected";
            }
            else {
                joystick.Text = "Not Connected";
            }

            if (checkBox1.Checked)
            {
                moto = true;
                joyfound = true;
            }
            else
            {
                moto = false;
                joyfound = false;
            }

            servo[0] = 3000; //Stop Position
            servo[1] = 3000;

            if (operate.Checked)
            {
                label3.Text = "On";
                label3.ForeColor = Color.Green;
            }
            else
            {
                label3.Text = "Off";
                label3.ForeColor = Color.Red;
            }

            if (moto)
            {
                try
                {
                    motoControl.motors[0].Velocity = Limit_Device((int)(((0.052) * (LeftFront)) + 119), Phidget_Max, Phidget_Min); //pin 0
                    motoControl.motors[1].Velocity = Limit_Device((int)(((0.052) * (LeftFront)) + 119), Phidget_Max, Phidget_Min); //pin 1
                    motoControl.motors[2].Velocity = Limit_Device((int)(((0.052) * (LeftBack)) + 119), Phidget_Max, Phidget_Min); //pin 2
                    motoControl.motors[3].Velocity = Limit_Device((int)(((0.052) * (RightFront)) + 119), Phidget_Max, Phidget_Min); //pin 3
                }
                catch (Exception r)
                {
                }
            }
        }

        private void ErrorCheck_Tick(object sender, EventArgs e)
        {
            if (motorController.Text != "Connected")
            {
                errorProvider1.SetError(motorController, "Connect a motor controller");
            }
            else {
                errorProvider1.SetError(motorController, "");
            }
            if (joystick.Text != "Connected")
            {
                errorProvider1.SetError(joystick, "Connect a joystick");
            }
            else
            {
                errorProvider1.SetError(joystick, "");
            }
        }

        private void operate_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
