﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace ODonel_Simple_ROV_Controller
{
    public partial class CameraAngle : UserControl
    {
        public CameraAngle()
        {
            InitializeComponent();
        }

        private int _maxAngle = 0;
        private int _minAngle = 0;
        private int _angle = 0;
        private bool _flipState = false;

        public bool FlipGraph
        {
            get
            {
                return _flipState;
            }
            set
            {
                _flipState = value;
            }

        }
        public int MaxAngle { get { return _maxAngle; } set { _maxAngle = value; } }
        public int MinAngle { get { return _minAngle; } set { _minAngle = value; } }
        public int Angle { get { return _angle; } set { _angle = value; RegenerateGraph(); } }

        private void RegenerateGraph()
        {
            Image img = new Bitmap(angleBox.Width, angleBox.Height);
            Graphics g = Graphics.FromImage(img);

            Pen border = new Pen(Brushes.Black);
            Brush bar = Brushes.DarkBlue;

            g.DrawRectangle(border, 1, 1, img.Width - 3, img.Height - 3);

            g.DrawLine(border, img.Width / 2, 1, img.Width / 2, img.Height - 2);
            g.DrawLine(border, 1, img.Height / 2, img.Width - 2, img.Height / 2);


            //percentage of full width that angle is located
            int range = MaxAngle - MinAngle;
            int trueAngle = Angle - MinAngle;

            double perc = (double)trueAngle / (double)range;

            if ((trueAngle == 0) && (range == 0))
            {
                perc = 0.5;
            }

            if (FlipGraph)
            {
                perc = 1.0 - perc;
            }


            int barHeight = 5;
            g.FillRectangle(bar, 0, (((int)((double)img.Height * perc)) - (barHeight / 2)), img.Width, barHeight);

            //g.DrawLine(border, 1, (int)((double)img.Height * perc), img.Width - 2, (int)((double)img.Height * perc));


            g.Save();
            angleBox.Image = img;
        }
    }
}
