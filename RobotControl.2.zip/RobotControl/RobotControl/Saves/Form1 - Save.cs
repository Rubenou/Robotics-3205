﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Phidgets;
using Phidgets.Events;
using Microsoft.DirectX.DirectInput;
using Microsoft.DirectX;

namespace RobotControl
{

    public partial class Form1 : Form
    {

        #region Declorations
        MotorControl motoControl; //Declare a MotorControl object
        bool motor1on; 
        bool joyfound = false; //This is used to allow the program to start up without needing to have a joystick plugged in.
        int Phidget_Max = 231; //Max Speed
        int Phidget_Min = -23; //Min Speed
		const byte START = 0x80; //defining any constant values that need to be reference is also a good practice
        const byte DEVICE = 0x01;//defining any constant values that need to be reference is also a good practice
        const byte COMMAND = 0x04;//defining any constant values that need to be reference is also a good practice
        #endregion

        #region Functions
        void motoControl_Attach(object sender, AttachEventArgs e)
        {
            motor1on = true;

        }
        void motoControl_Detach(object sender, DetachEventArgs e)
        {
            motor1on = false;

        }
        int Limit_Device(int variable, int max, int min)
        {
            if (variable > max) { variable = max; }
            if (variable < min) { variable = min; }
            return variable;
        }
		byte[] Create_Message(int variable, int servonum)
        {

            byte lsb = (byte)(variable & 0x7F);
            byte msb = (byte)(variable >> 7);

            byte servo = (byte)((int)(servonum));
            byte[] message = { START, DEVICE, COMMAND, servo, msb, lsb };
            return message;
        }
        #endregion

        #region Joystick

        #endregion

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            motoControl = new MotorControl();
            motoControl.Attach += new AttachEventHandler(motoControl_Attach);
            motoControl.Detach += new DetachEventHandler(motoControl_Detach);
			try
            {
                motoControl.open(); 
            }
            catch (PhidgetException pe)
            {
                MessageBox.Show(pe.ToString());
            }
            timer1.Enabled = true;
            ErrorCheck.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (motor1on)
            { //we check to see if our Phidget is still connected.
                motorController.Text = "Connected";  //display the status of our phidget
            }
            else {
                motorController.Text = "Not Connected"; //display the status of our phidget
            }
            if (joyfound)
            {
                joystick.Text = "Connected";
            }
            else {
                joystick.Text = "Not Connected";
            }
			
			int RightFront; //Right Front Wheel             
            int RightBack; // Right Back Wheel
            int LeftFront; // Left Front Wheel
            int LeftBack; //Left Back Wheel
			int[] servo = new int[2];   //there are some variable that we might need for this section, which are commonly used in ROVs

            servo[0] = 3000; //Stop Position
            servo[1] = 3000;

            if (operate.Checked)
            {
                label3.Text = "On";
                label3.ForeColor = Color.Green;
                if (motor1on)
                {
                    try
                    {
                        //motoControl.motors[0].Velocity = Limit_Device((int)(((0.052) * (RightBack)) + 119), Phidget_Max, Phidget_Min); //pin 0
                        // motoControl.motors[1].Velocity = Limit_Device((int)(((0.052) * (LeftFront)) + 119), Phidget_Max, Phidget_Min); //pin 1
                        // motoControl.motors[2].Velocity = Limit_Device((int)(((0.052) * (LeftBack)) + 119), Phidget_Max, Phidget_Min); //pin 2
                        //motoControl.motors[3].Velocity = Limit_Device((int)(((0.052) * (RightFront)) + 119), Phidget_Max, Phidget_Min); //pin 3
                    }
                    catch (Exception r)
                    {
                    }
                }
            }
            else
            {
                label3.Text = "Off";
                label3.ForeColor = Color.Red;
            }
        }

        private void ErrorCheck_Tick(object sender, EventArgs e)
        {
            if (motorController.Text != "Connected")
            {
                errorProvider1.SetError(motorController, "Connect a motor controller");
            }
            else {
                errorProvider1.SetError(motorController, "");
            }
            if (joystick.Text != "Connected")
            {
                errorProvider1.SetError(joystick, "Connect a joystick");
            }
            else
            {
                errorProvider1.SetError(joystick, "");
            }
        }

        private void operate_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
